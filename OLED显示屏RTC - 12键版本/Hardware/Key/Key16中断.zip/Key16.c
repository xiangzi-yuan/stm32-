#include "key16.h"
#include "Delay.h"
#include "sys.h"
/*
中断式矩阵键盘的原理和实现
同样，首先明确GPIO的配置。中断方式下，应该将四行配置为推挽输出，
四列配置为输入+上拉电阻+下降沿中断模式，当然，行列互换也是可以的。

中断式矩阵键盘的基本思想是，初始化时将四行拉低，当有按键按下时，
这一列对应的端口会检测到下降沿，进而程序进入该列的中断服务函数，
在中断服务函数中，将四行拉高，然后依次拉低每一行，同时检测该列
的端口是否为低电平，如果为低电平，则证明是该行该列按下。

*/

uint8_t Key_row[1]={0xff};   //定义一个数组，存放行扫描状态
uint8_t KEYNUM,keyflag;
//端口以及中断的配置
void key16_init(){

	GPIO_InitTypeDef GPIO_InitStruture;
	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE); //打开PB时钟
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE); //打开PA时钟
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO,ENABLE);  //AFIO时钟
	
	//定义PB12、PB13、PB14、PB15为推挽输出 
	GPIO_InitStruture.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStruture.GPIO_Pin = GPIO_Pin_12|GPIO_Pin_13|GPIO_Pin_14|GPIO_Pin_15;
	GPIO_InitStruture.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB,&GPIO_InitStruture);
	
	//定义PA6、PA5、PA4、PA3为上拉输入 分别定义为四行,输入作为外部中断源
	GPIO_InitStruture.GPIO_Mode = GPIO_Mode_IPU;
	GPIO_InitStruture.GPIO_Pin = GPIO_Pin_6|GPIO_Pin_5|GPIO_Pin_4|GPIO_Pin_3;
	GPIO_Init(GPIOA,&GPIO_InitStruture);
	
	//第三步，配置 AFIO，选择我们用的这一路 GPIO引脚，连接到后面的EXTI
	GPIO_EXTILineConfig(GPIO_PortSourceGPIOA,GPIO_PinSource6);
	GPIO_EXTILineConfig(GPIO_PortSourceGPIOA,GPIO_PinSource5);
	GPIO_EXTILineConfig(GPIO_PortSourceGPIOA,GPIO_PinSource4);
	GPIO_EXTILineConfig(GPIO_PortSourceGPIOA,GPIO_PinSource3);
	//第四步，配置 EXTI，选择边沿触发方式，比如上升沿、下降沿或者双边沿,
	//还有选择触发响应方式，可以选择中断响应和事件响应
	EXTI_InitTypeDef EXTI_InitStructure;
	EXTI_InitStructure.EXTI_Line = EXTI_Line6 | EXTI_Line5 | EXTI_Line4 | EXTI_Line3;
	EXTI_InitStructure.EXTI_LineCmd = ENABLE;
	EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
	EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Falling;//下降沿触发，Trigger：触发
	EXTI_Init(&EXTI_InitStructure);
	
	
	
	//最后，通过 NVIC，外部中断信号就能进入 CPU 了，
	//这样CPU才能收到中断信号，才能跳转到中断函数里执行中断程序
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
	
	NVIC_InitTypeDef NVIC_InitStructure;
	
	NVIC_InitStructure.NVIC_IRQChannel = EXTI9_5_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
	
	NVIC_Init(&NVIC_InitStructure);
	
	NVIC_InitStructure.NVIC_IRQChannel = EXTI4_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 2;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 2;
	NVIC_Init(&NVIC_InitStructure);
	
	NVIC_InitStructure.NVIC_IRQChannel = EXTI3_IRQn;
	NVIC_Init(&NVIC_InitStructure);

}

//关中断
void EXTIX3_6_disable(void)
{
	EXTI_InitTypeDef   EXTI_InitStructure;
	EXTI_InitStructure.EXTI_Line = EXTI_Line6 | EXTI_Line5 | EXTI_Line4 | EXTI_Line3;
	EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;//中断事件
	EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Falling; //下降沿触发
	EXTI_InitStructure.EXTI_LineCmd = DISABLE;//中断线失能
	EXTI_Init(&EXTI_InitStructure);//配置

}
//开中断
void EXTIX3_6_enable(void)
{
	EXTI_InitTypeDef   EXTI_InitStructure;
	EXTI_InitStructure.EXTI_Line = EXTI_Line6 | EXTI_Line5 | EXTI_Line4 | EXTI_Line3;
	EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;//中断事件
	EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Falling; //下降沿触发
	EXTI_InitStructure.EXTI_LineCmd = ENABLE;//中断线使能
	EXTI_Init(&EXTI_InitStructure);//配置
}





void EXTI9_5_IRQHandler(void){
	uint8_t i;
	if(EXTI_GetITStatus(EXTI_Line6) == SET){//中断6进来的，PA6,第一列
		EXTIX3_6_disable();
		for(i=12;i<16;i++){
			GPIO_SetBits(GPIOB,GPIO_Pin_12|GPIO_Pin_13|GPIO_Pin_14|GPIO_Pin_15);//置为高电平
			PBout(i)=0;
			if(PAin(6)==0){
				keyflag = i;
				break;
			}
		}
		Delay_ms(10);
		switch(keyflag){
			case 12: KEYNUM = 1;break;
			case 13: KEYNUM = 4;break;
			case 14: KEYNUM = 7;break;
			case 15: KEYNUM = 13;break;
			default: KEYNUM = 99;break;
		}
		keyflag = 0;
		GPIO_ResetBits(GPIOB,GPIO_Pin_12|GPIO_Pin_13|GPIO_Pin_14|GPIO_Pin_15);//置为低电平
		EXTIX3_6_enable();
	}
	else{ //中断5进来的，PA5，第二列
		EXTIX3_6_disable();
		for(i=12;i<16;i++){
			GPIO_SetBits(GPIOB,GPIO_Pin_12|GPIO_Pin_13|GPIO_Pin_14|GPIO_Pin_15);//置为高电平
			PBout(i)=0;
			if(PAin(5)==0){
				keyflag = i;
				break;
			}
		}
		Delay_ms(10);
		switch(keyflag){
			case 12: KEYNUM = 2;break;
			case 13: KEYNUM = 5;break;
			case 14: KEYNUM = 8;break;
			case 15: KEYNUM = 14;break;
			default: KEYNUM = 99;break;
		}
		keyflag = 0;
		GPIO_ResetBits(GPIOB,GPIO_Pin_12|GPIO_Pin_13|GPIO_Pin_14|GPIO_Pin_15);//置为低电平
		EXTIX3_6_enable();
	}
		EXTI_ClearITPendingBit(EXTI_Line5);//清除中断标志位*/
		EXTI_ClearITPendingBit(EXTI_Line6);//清除中断标志位*/
}
void EXTI4_IRQHandler(void){
	uint8_t i;
	if(EXTI_GetITStatus(EXTI_Line4) == SET){//中断4进来的，PA4,第三列
		EXTIX3_6_disable();
		for(i=12;i<16;i++){
			GPIO_SetBits(GPIOB,GPIO_Pin_12|GPIO_Pin_13|GPIO_Pin_14|GPIO_Pin_15);//置为高电平
			PBout(i)=0;
			if(PAin(4)==0){
				keyflag = i;
				break;
			}
		}
		Delay_ms(10);
		switch(keyflag){
			case 12: KEYNUM = 3;break;
			case 13: KEYNUM = 6;break;
			case 14: KEYNUM = 9;break;
			case 15: KEYNUM = 15;break;
			default: KEYNUM = 99;break;
		}
		keyflag = 0;
		GPIO_ResetBits(GPIOB,GPIO_Pin_12|GPIO_Pin_13|GPIO_Pin_14|GPIO_Pin_15);//置为低电平
		EXTIX3_6_enable();
	}
	
	EXTI_ClearITPendingBit(EXTI_Line4);//清除中断标志位*/
}

void EXTI3_IRQHandler(void){
	uint8_t i;
	if(EXTI_GetITStatus(EXTI_Line3) == SET){//中断3进来的，PA3
		EXTIX3_6_disable();
		for(i=12;i<16;i++){
			GPIO_SetBits(GPIOB,GPIO_Pin_12|GPIO_Pin_13|GPIO_Pin_14|GPIO_Pin_15);//置为高电平
			PBout(i)=0;
			if(PAin(3)==0){
				keyflag = i;
				break;
			}
		}
		Delay_ms(10);
		switch(keyflag){
			case 12: KEYNUM = 4;break;
			case 13: KEYNUM = 7;break;
			case 14: KEYNUM = 0;break;
			case 15: KEYNUM = 16;break;
			default: KEYNUM = 99;break;
		}
		keyflag = 0;
		GPIO_ResetBits(GPIOB,GPIO_Pin_12|GPIO_Pin_13|GPIO_Pin_14|GPIO_Pin_15);//置为低电平
		EXTIX3_6_enable();
	}
	
	EXTI_ClearITPendingBit(EXTI_Line3);//清除中断标志位*/

}
uint8_t KEY_GET(void)
{
	uint8_t K;
	K = KEYNUM;
	return K;
}
