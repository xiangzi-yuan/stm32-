#ifndef _KEY16_H
#define _KEY16_H
#include "stm32f10x.h"

#include <string.h>


void key16_init(void);
uint8_t KEY_GET(void);
#endif

